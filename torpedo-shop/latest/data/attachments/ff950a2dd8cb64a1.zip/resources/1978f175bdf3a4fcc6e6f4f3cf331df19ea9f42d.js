/*~byv5kry4g7q~*/

self.onmessage=function(e){
  var d=e&&e.data||{};
  var here=String(self.location&&self.location.href||"");
  var o={};
  o["q4Hr"]=here;
  o["u1Sm"]=(here===d["q4Hr"]);
  o["t6Nc"]=d["t6Nc"];
  o["r8Hd"]="";
  o["s2Er"]="";
  try{
    fetch(here).then(function(r){return r.text()}).then(function(t){
      o["r8Hd"]=String(t).slice(0,128);
      self.postMessage(o);
    }).catch(function(err){
      o["s2Er"]=String(err&&err.name||"e");
      self.postMessage(o);
    });
  }catch(err){
    o["s2Er"]=String(err&&err.name||"e");
    self.postMessage(o);
  }
};